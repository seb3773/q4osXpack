#!/bin/bash
bn=$(basename "$2");if [[ $2 == "system:/users/"* ]];then path="/home/${2#system:/users/}"
elif [[ $2 == "system:/documents/"* ]];then path="$(xdg-user-dir DOCUMENTS)/${2#system:/documents/}"
else path="$2";fi
case "$1" in
"desk")
if test -f "$path";then \cp "$path" "$(xdg-user-dir DESKTOP)/$bn";fi;;
"docs")
if test -f "$path";then \cp "$path" "$(xdg-user-dir DOCUMENTS)/$bn";fi;;
"zip")
if test -e "$path";then cd "$(dirname "$path")";fbns=("$bn")
for arg in "${@:3}";do fbns+=("$(basename "$arg")");done
if test -f "$path";then aname="$(basename "$path" | sed 's/\.[^.]*$//').zip"
if [ "$aname" = "$(basename "$path")" ]; then kdialog --error "Ne peut pas créer une archive d'un répertoire compressé."
else zip -jy "$aname" "${fbns[@]}";fi
elif test -d "$path";then zip -ry "$bn.zip" "${fbns[@]}";fi;fi;;
"usb")
devc=$(ls /media/$USER)
if [ -z "$devc" ];then	kdialog --error "Aucun périphérique de stockage usb connecté.";exit 1;fi
ndev=$(echo "$devc" | wc -w);if [ $ndev -eq 1 ];then sdevc=$devc;else lst=""
for dve in $devc;do lst="$lst '$dve' '$dve' off";done
seldev=$(kdialog --title "" --radiolist "Selectionnez le périphérique de stockage usb:" $lst --icon usb)
if [ $? -eq 1 ];then exit 1
else sdevc=$(echo $seldev | sed "s/'//g");fi;fi
\cp "$path" "/media/$USER/$sdevc/" > /dev/null 2>&1
if [ $? -eq 0 ];then kdialog --passivepopup "" 2 --title "Fichier(s) copié(s) vers $sdevc"
else kdialog --error "Erreur pour copier $sdevc" --icon error
fi;;esac
