#!/bin/bash
bn=$(basename "$2");if [[ $2 == "system:/users/"* ]];then path="/home/${2#system:/users/}"
elif [[ $2 == "system:/documents/"* ]];then path="$(xdg-user-dir DOCUMENTS)/${2#system:/documents/}"
elif [[ $2 == "system:/media/"* ]];then input=$2;device=$(echo "$input" | awk -F 'system:/media/' '{print $2}' | awk -F '/' '{print $1}')
dpath="$(lsblk -no MOUNTPOINT /dev/$device)";path="$dpath/$(echo "$input" | sed "s|system:/media/$device/||")"
else path="$2";fi
case "$1" in
"desk") if test -f "$path";then \cp "$path" "$(xdg-user-dir DESKTOP)/$bn";fi;;
"docs") if test -f "$path";then \cp "$path" "$(xdg-user-dir DOCUMENTS)/$bn";fi;;
"zip") if test -e "$path";then cd "$(dirname "$path")";fbns=("$bn")
for arg in "${@:3}";do fbns+=("$(basename "$arg")");done
if test -f "$path";then aname="$(basename "$path" | sed 's/\.[^.]*$//').zip"
if [ "$aname" = "$(basename "$path")" ]; then kdialog --error "Ne peut pas créer une archive d'un répertoire compressé."
else zip -jy "$aname" "${fbns[@]}"
if [ $? -eq 0 ]; then
if zip -T "$aname" > /dev/null 2>&1; then
kdialog --passivepopup "Archive $aname créée avec succès" 2
else kdialog --error "L'archive $aname a été créée mais semble être corrompue";fi
else kdialog --error "Erreur lors de la création de l'archive $aname";fi;fi
elif test -d "$path";then zip -ry "$bn.zip" "${fbns[@]}"
if [ $? -eq 0 ]; then
if zip -T "$bn.zip" > /dev/null 2>&1; then
kdialog --passivepopup "Archive $bn.zip créée avec succès" 2
else kdialog --error "L'archive $bn.zip a été créée mais semble être corrompue";fi
else kdialog --error "Erreur lors de la création de l'archive $bn.zip";fi;fi;fi;;
"usb") devc=$(ls /media/$USER)
if [ -z "$devc" ];then	kdialog --error "Aucun périphérique de stockage usb connecté.";exit 1;fi
ndev=$(echo "$devc" | wc -w);if [ $ndev -eq 1 ];then sdevc=$devc;else lst=""
for dve in $devc;do lst="$lst '$dve' '$dve' off";done
seldev=$(kdialog --title "" --radiolist "Selectionnez le périphérique de stockage usb:" $lst --icon usb)
if [ $? -eq 1 ];then exit 1
else sdevc=$(echo $seldev | sed "s/'//g");fi;fi
cd "$(dirname "$path")";args=("$@");files=()
for arg in "${args[@]:1}"; do files+=("$(basename "$arg")");done
total_files=${#files[@]};numf=0;success_count=0
dcopRef=$(kdialog --icon "usb" --title "Copie vers /media/$USER/$sdevc/" --geometry 450 100 --caption "" --progressbar "" 100 )
for file in "${files[@]}"; do
if [ -f "$file" ]; then ((numf++));dcop "$dcopRef" setLabel "Copie ($numf / $total_files ...)"
\cp "$file" "/media/$USER/$sdevc/" > /dev/null 2>&1
if [ $? -eq 0 ]; then kdialog --passivepopup "Fichier $file copié vers $sdevc" 2
((success_count++));else kdialog --error "Erreur lors de la copie de $file vers $sdevc" --icon error
fi;else kdialog --error "Le fichier $file n'existe pas ou n'est pas un fichier régulier" --icon error
fi;prognum=$(echo "$numf * 100 / $total_files" | bc);dcop "$dcopRef" setProgress $prognum
done;dcop "$dcopRef" close
if [ $success_count -eq $total_files ]; then kdialog --passivepopup "Tous les fichiers ($total_files) ont été copiés avec succès vers $sdevc" 2
else kdialog --passivepopup "$success_count sur $total_files fichiers ont été copiés vers $sdevc" 2
fi;;
"remote") if test -f "$path"; then cd "$(dirname "$path")"
remotepath="${!#}";args=("$@");files=("${args[@]:1:$#-2}")
success_count=0;total_files=${#files[@]};numf=0
dcopRef=$(kdialog --icon "folder-remote" --title "SendTo $remotepath" --geometry 450 100 --caption "" --progressbar "" 100 )
for file in "${files[@]}"; do basename_file=$(basename "$file")
if [[ -f "$basename_file" ]]; then ((numf++));dcop "$dcopRef" setLabel "Envoi ($numf / $total_files ...)"
rclone copy "$basename_file" "$remotepath"
if [ $? -eq 0 ]; then  ((success_count++));kdialog --passivepopup "Fichier \"$basename_file\" copié vers $remotepath" 2
else kdialog --error "Erreur lors de la copie de \"$basename_file\" vers $remotepath" --icon error
fi;else kdialog --error "Le fichier \"$basename_file\" n'existe pas ou n'est pas un fichier valide." --icon error
fi;prognum=$(echo "$numf * 100 / $total_files" | bc);dcop "$dcopRef" setProgress $prognum;done;dcop "$dcopRef" close;
if [ $success_count -eq $total_files ]; then kdialog --passivepopup "Tous les fichiers ($total_files) ont été transférés avec succès vers $remotepath" 2
else kdialog --passivepopup "$success_count sur $total_files fichiers ont été transférés vers $remotepath" 2
fi;fi;;
esac
