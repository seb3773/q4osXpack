#!/bin/bash
USER_HOME=$(eval echo ~${SUDO_USER})
SERVICE_MENU_FILE="$USER_HOME/.trinity/share/apps/konqueror/servicemenus/SendTo.desktop"
col_lrbg='\033[101m';col_wt='\033[97m';col_r='\033[0m';col_lrt='\033[91m';col_lgt='\033[92m'
col_lot='\033[38;5;214m';col_bt='\033[30m';col_ybg='\033[43m';col_dgbg='\033[100m';col_mag='\033[105m'
col_lcy='\033[96m';col_lm='\033[95m'
col_wt='\033[97m';col_lbbg='\033[104m';col_cy='\033[46m';echo -e -n "${col_r}"
add_new_entry() {
remotes=$(rclone listremotes)
if [ -z "$remotes" ]; then
echo -e "${col_lrt}Aucune remote configurée trouvée. Sortie.${col_r}"
exit 1;fi
echo -e "${col_lbbg}${col_wt}»» Sélectionnez une remote : ${col_r} (ou ctrl+c pour retourner au menu principal)"
trap "trap SIGINT;echo;return" SIGINT
select remote in $remotes; do
if [ -n "$remote" ]; then remtype=$(rclone listremotes --long | grep "^${remote}" | awk '{print $2}')
echo -e "Vous avez sélectionné : $remote  -- ${col_lgt}[ Type de remote : $remtype ]${col_r}"
break
else echo -e "${col_lrt}Sélection invalide. Veuillez réessayer.${col_r}"
fi;done
echo -e "${col_mag}${col_bt}»» Entrez le chemin du répertoire pour recevoir les fichiers${col_r} (existant ou nouveau)"
echo -e -n "${col_wt}"
read dir_path
echo -e -n "${col_r}"
echo -e -n "Vérification..."
if rclone lsd "${remote}${dir_path}" &>/dev/null; then echo -e "${col_lgt}Ok, le répertoire existe sur la remote.${col_r}"
else echo;echo "Le répertoire n'existe pas sur la remote, tentative de création..."
echo -e -n "${col_lot}"
if rclone mkdir "${remote}${dir_path}"; then echo -e -n "${col_r}"
echo -e "${col_lgt}Répertoire créé avec succès sur la remote.${col_r}"
else echo -e "${col_lrbg}${col_wt}Erreur : Échec de la création du répertoire sur la remote ${remote} ${col_r}"
trap SIGINT;return
fi;fi
echo -e -n "Test des permissions d'écriture..."
test_file="${remote}${dir_path}/write_test_$(date +%s)"
if ! echo "test" | rclone rcat "$test_file" 2>/dev/null; then
echo;echo -e "${col_lrbg}${col_wt}Erreur : Impossible d'écrire dans le répertoire spécifié. Veuillez vérifier vos permissions.${col_r}"
trap SIGINT;return
else echo -e "${col_lgt}Ok.${col_r}"
fi
rclone delete "$test_file" 2>/dev/null
while true; do
echo -e "${col_cy}${col_bt}»» Entrez un nom personnalisé pour cette remote dans le menu ${col_r} (ou appuyez sur Entrée pour utiliser \"${remote}\") :"
echo -e -n "${col_wt}"
read custom_name
echo -e -n "${col_r}"
if [ -z "$custom_name" ]; then custom_name="${remote%:}"
break
else
cleaned_name=$(echo "${custom_name}" | tr -cd '[:alnum:]_-')
if [ "$cleaned_name" = "$custom_name" ]; then break
else echo -e "${col_lrt}Caractères non valides détectés. Veuillez utiliser uniquement des caractères alphanumériques, des soulignés (_) et des tirets (-).${col_r}"
echo "Souhaitez-vous utiliser \"$cleaned_name\" à la place ? (o/n)"
read response
if [[ $response =~ ^[Oo]$ ]]; then custom_name=$cleaned_name
break
fi;fi;fi
done
trap SIGINT
echo -e "Utilisation du nom : ${col_lgt} ${custom_name} ${col_r}"
echo -e "${col_lgt}Configuration de la remote et du répertoire terminée.${col_r}";echo
if [ ! -f "$SERVICE_MENU_FILE" ]; then
echo "Fichier de menu de service non trouvé. Création en cours..."
mkdir -p "$(dirname "$SERVICE_MENU_FILE")"
touch "$SERVICE_MENU_FILE";fi
if ! echo "$rem_type" | grep -E -q "combine|ftp|http|smb|sftp"; then remtype="${remtype// /_}"
if [ ! -e "/usr/share/icons/hicolor/128x128/apps/${remtype}.png" ]; then echo "Tentative de récupération de l'icône pour le type de remote ${remtype}"
wget -q "https://github.com/seb3773/icons_repo/blob/main/sendtoremote/${remtype}.png?raw=true" -O "/tmp/${remtype}.png"
if [ $? -eq 0 ]; then
if [ ! "$EUID" -eq 0 ];then echo "Nous avons besoin d'une autorisation pour copier l'icône dans le dossier '/usr/share/icons/hicolor/'";fi
sudo cp -f "/tmp/${remtype}.png" "/usr/share/icons/hicolor/128x128/apps/${remtype}.png"
rem_icon="$remtype"
rm -f "/tmp/${remtype}.png"
else rem_icon="folder-remote";fi
else rem_icon="$remtype";fi
else rem_icon="folder-remote";fi
NEW_ENTRY="[Desktop Action sendtoremote_${custom_name}]
Name=${custom_name}
Icon=${rem_icon}
Exec=sendto.sh remote %U \"${remote}${dir_path}\"
"
if grep -q "sendtoremote_${custom_name}" "$SERVICE_MENU_FILE"; then echo -e "${col_lrt}L'entrée pour ${custom_name} existe déjà dans le menu de service.${col_r}"
else echo "Ajout d'une nouvelle entrée au menu de service..."
echo "$NEW_ENTRY" >> "$SERVICE_MENU_FILE"
echo -e "${col_lgt}Entrée ajoutée avec succès.${col_r}"
if grep -q "^\[Desktop Entry\]" "$SERVICE_MENU_FILE"; then if ! grep -q "^Actions=" "$SERVICE_MENU_FILE"; then
sed -i "/\[Desktop Entry\]/a Actions=sendtoremote_${custom_name}" "$SERVICE_MENU_FILE"
else sed -i "/^Actions=/ s/$/;sendtoremote_${custom_name}/" "$SERVICE_MENU_FILE"
fi
else DESKTOP_ENTRY="[Desktop Entry]
X-TDE-ServiceTypes=all/allfiles
X-TDE-Priority=TopLevel
X-TDE-Submenu=Send to
X-TDE-Submenu[fr]=Envoyer vers
X-TDE-Submenu[de]=Senden an
Actions=sendtoremote_${custom_name}"
sed -i "1i$DESKTOP_ENTRY" "$SERVICE_MENU_FILE";fi
echo "Section [Desktop Entry] mise à jour avec succès.";fi
echo -e "${col_lgt}Mise à jour du menu de service terminée.${col_r}";}
remove_existing_entry() {
if [ ! -f "$SERVICE_MENU_FILE" ]; then echo -e "${col_lrbg}${col_wt}Fichier de menu de service 'SendTo.desktop' introuvable. Aucune entrée à supprimer. \"$1\"${col_r}"
return;fi
entries=$(grep "\[Desktop Action sendtoremote_" "$SERVICE_MENU_FILE" | sed 's/\[Desktop Action sendtoremote_\(.*\)\]/\1/')
if [ -z "$entries" ]; then echo -e "${col_lrt}Aucune entrée 'envoyer vers remote' trouvée.${col_r}"
return;fi
echo -e "${col_ybg}${col_wt}»» Sélectionnez une entrée à supprimer :${col_r} (ou ctrl+c pour revenir au menu principal)"
trap "trap SIGINT;echo;return" SIGINT
select entry in $entries; do
if [ -n "$entry" ]; then echo -e "${col_lot}Vous avez choisi de supprimer : $entry ${col_r}"
sed -i "/\[Desktop Action sendtoremote_${entry}\]/,/\[Desktop Action/{\
	/\[Desktop Action sendtoremote_${entry}\]/d;\
	/\[Desktop Action/!d\
}" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/sendtoremote_${entry};//g" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/;sendtoremote_${entry}//g" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/sendtoremote_${entry}//g" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/;$//g" "$SERVICE_MENU_FILE"
echo -e "${col_lgt}Entrée supprimée avec succès.${col_r}"
break
else echo -e "${col_lrt}Sélection invalide. Veuillez réessayer.${col_r}"
fi;done;trap SIGINT;}
echo
while true; do
echo -e "${col_dgbg}${col_wt}► Sélectionnez une option :${col_r}"
echo -e "1. ${col_lcy}Ajouter une nouvelle entrée 'envoyer vers remote'${col_r}"
echo -e "2. ${col_lot}Supprimer une entrée 'envoyer vers remote' existante${col_r}"
echo -e "3. ${col_lrt}Quitter${col_r}"
read -p "Entrez votre choix (1-3): " choice
case $choice in
1) add_new_entry;;
2) remove_existing_entry;;
3) echo -e "${col_lm}Sortie.${col_r}";echo
exit 0;;
*) echo -e "${col_lrt}Choix invalide. Entrez 1, 2, ou 3.${col_r}";;
esac
echo
done
