#!/bin/bash
prog=$(basename "$1")
if [ "$prog" = "konsole.desktop" ]; then konsole --type su; else
tdesudo -c ls /dev/null -d -i password --comment "Run $prog as root"
CANSUDO=$(sudo -n echo 1 2>&1 | grep 1)
if [[ $CANSUDO -eq 1 ]];then sudo gtk-launch "$prog";fi
fi