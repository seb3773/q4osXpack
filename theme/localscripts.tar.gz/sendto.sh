#!/bin/bash
bn=$(basename "$2")
case "$1" in
"desk")
if test -f "$2"; then \cp "$2" "$(xdg-user-dir DESKTOP)/$bn";fi;;
"docs")
if test -f "$2"; then \cp "$2" "$(xdg-user-dir DOCUMENTS)/$bn";fi;;
"zip")
if test -e "$2"; then cd "$(dirname "$2")"
file_basenames=("$bn")
for arg in "${@:3}"; do file_basenames+=("$(basename "$arg")");done
if test -f "$2"; then
aname="$(basename "$2" | sed 's/\.[^.]*$//').zip"
if [ "$aname" = "$(basename "$2")" ]; then
kdialog --error "Can't create compressed of folder of a compressed folder."
else zip -jy "$aname" "${file_basenames[@]}";fi
elif test -d "$2"; then zip -ry "$bn.zip" "${file_basenames[@]}";fi;fi;;
esac