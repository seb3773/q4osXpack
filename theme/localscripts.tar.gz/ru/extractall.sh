#!/bin/bash
dn=$(dirname "$1");bn="$(basename "$1" | sed 's/\.[^.]*$//')"
mkdir -p "$dn/$bn";extractdir=$(kdialog --title "Выберите целевую папку и извлеките файлы" --icon zip --getexistingdirectory "$dn/$bn")
if [ -n "$extractdir" ];then if [ "$extractdir" != "$dn/$bn" ];then rm -r "$dn/$bn";fi;unzip "$1" -d "$extractdir"
konqueror "$extractdir" &
else rm -r "$dn/$bn";fi