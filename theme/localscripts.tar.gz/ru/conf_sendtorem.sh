#!/bin/bash
USER_HOME=$(eval echo ~${SUDO_USER})
SERVICE_MENU_FILE="$USER_HOME/.trinity/share/apps/konqueror/servicemenus/SendTo.desktop"
col_lrbg='\033[101m';col_wt='\033[97m';col_r='\033[0m';col_lrt='\033[91m';col_lgt='\033[92m'
col_lot='\033[38;5;214m';col_bt='\033[30m';col_ybg='\033[43m';col_dgbg='\033[100m';col_mag='\033[105m'
col_lcy='\033[96m';col_lm='\033[95m'
col_wt='\033[97m';col_lbbg='\033[104m';col_cy='\033[46m';echo -e -n "${col_r}"
add_new_entry() {
remotes=$(rclone listremotes)
if [ -z "$remotes" ]; then
echo -e "${col_lrt}Не найдено настроенных удалённых репозиториев. Выход.${col_r}"
exit 1;fi
echo -e "${col_lbbg}${col_wt}»» Выберите удалённый репозиторий: ${col_r} (или ctrl+c для возврата в главное меню)"
trap "trap SIGINT;echo;return" SIGINT
select remote in $remotes; do
if [ -n "$remote" ]; then remtype=$(rclone listremotes --long | grep "^${remote}" | awk '{print $2}')
echo -e "Вы выбрали: $remote  -- ${col_lgt}[ Тип удалённого репозитория: $remtype ]${col_r}"
break
else echo -e "${col_lrt}Неверный выбор. Пожалуйста, попробуйте снова.${col_r}"
fi;done
echo -e "${col_mag}${col_bt}»» Введите путь к каталогу для получения файлов${col_r} (существующий или новый)"
echo -e -n "${col_wt}"
read dir_path
echo -e -n "${col_r}"
echo -e -n "Проверка..."
if rclone lsd "${remote}${dir_path}" &>/dev/null; then echo -e "${col_lgt}Ок, директория существует на удалённом сервере.${col_r}"
else echo;echo "Каталог не существует на удаленном сервере, пытаюсь его создать..."
echo -e -n "${col_lot}"
if rclone mkdir "${remote}${dir_path}"; then echo -e -n "${col_r}"
echo -e "${col_lgt}Каталог успешно создан на удаленном сервере.${col_r}"
else echo -e "${col_lrbg}${col_wt}Ошибка: Не удалось создать директорию на удалённом сервере ${remote} ${col_r}"
trap SIGINT;return
fi;fi
echo -e -n "Проверка прав на запись..."
test_file="${remote}${dir_path}/write_test_$(date +%s)"
if ! echo "test" | rclone rcat "$test_file" 2>/dev/null; then
echo;echo -e "${col_lrbg}${col_wt}Ошибка: Невозможно записать в указанную директорию. Проверьте ваши права доступа.${col_r}"
trap SIGINT;return
else echo -e "${col_lgt}Ok.${col_r}"
fi
rclone delete "$test_file" 2>/dev/null
while true; do
echo -e "${col_cy}${col_bt}»» Введите пользовательское имя для этого удаленного объекта в меню ${col_r} (или нажмите Enter для использования \"${remote}\"):"
echo -e -n "${col_wt}"
read custom_name
echo -e -n "${col_r}"
if [ -z "$custom_name" ]; then custom_name="${remote%:}"
break
else
cleaned_name=$(echo "${custom_name}" | tr -cd '[:alnum:]_-')
if [ "$cleaned_name" = "$custom_name" ]; then break
else echo -e "${col_lrt}Обнаружены недопустимые символы. Пожалуйста, используйте только буквенно-цифровые символы, подчеркивания и дефисы.${col_r}"
echo "Хотите использовать \"$cleaned_name\" вместо этого? (y/n)"
read response
if [[ $response =~ ^[Yy]$ ]]; then custom_name=$cleaned_name
break
fi;fi;fi
done
trap SIGINT
echo -e "Используется имя: ${col_lgt} ${custom_name} ${col_r}"
echo -e "${col_lgt}Настройка удаленного доступа и каталога завершена.${col_r}";echo
if [ ! -f "$SERVICE_MENU_FILE" ]; then
echo "Файл меню службы не найден. Создание файла..."
mkdir -p "$(dirname "$SERVICE_MENU_FILE")"
touch "$SERVICE_MENU_FILE";fi
if ! echo "$rem_type" | grep -E -q "combine|ftp|http|smb|sftp"; then remtype="${remtype// /_}"
if [ ! -e "/usr/share/icons/hicolor/128x128/apps/${remtype}.png" ]; then echo "Попытка получения значка для типа удаленного объекта ${remtype}"
wget -q "https://github.com/seb3773/icons_repo/blob/main/sendtoremote/${remtype}.png?raw=true" -O "/tmp/${remtype}.png"
if [ $? -eq 0 ]; then
if [ ! "$EUID" -eq 0 ];then echo "Нам нужны разрешения для копирования значка в папку '/usr/share/icons/hicolor/'";fi
sudo cp -f "/tmp/${remtype}.png" "/usr/share/icons/hicolor/128x128/apps/${remtype}.png"
rem_icon="$remtype"
rm -f "/tmp/${remtype}.png"
else rem_icon="folder-remote";fi
else rem_icon="$remtype";fi
else rem_icon="folder-remote";fi
NEW_ENTRY="[Desktop Action sendtoremote_${custom_name}]
Name=${custom_name}
Icon=${rem_icon}
Exec=sendto.sh remote %U \"${remote}${dir_path}\"
"
if grep -q "sendtoremote_${custom_name}" "$SERVICE_MENU_FILE"; then echo -e "${col_lrt}Запись для ${custom_name} уже существует в меню служб.${col_r}"
else echo "Добавление новой записи в меню служб..."
echo "$NEW_ENTRY" >> "$SERVICE_MENU_FILE"
echo -e "${col_lgt}Запись успешно добавлена.${col_r}"
if grep -q "^\[Desktop Entry\]" "$SERVICE_MENU_FILE"; then if ! grep -q "^Actions=" "$SERVICE_MENU_FILE"; then
sed -i "/\[Desktop Entry\]/a Actions=sendtoremote_${custom_name}" "$SERVICE_MENU_FILE"
else sed -i "/^Actions=/ s/$/;sendtoremote_${custom_name}/" "$SERVICE_MENU_FILE"
fi
else DESKTOP_ENTRY="[Desktop Entry]
X-TDE-ServiceTypes=all/allfiles
X-TDE-Priority=TopLevel
X-TDE-Submenu=Send to
X-TDE-Submenu[fr]=Envoyer vers
X-TDE-Submenu[ru]=Отправить в
Actions=sendtoremote_${custom_name}"
sed -i "1i$DESKTOP_ENTRY" "$SERVICE_MENU_FILE";fi
echo "Секция [Desktop Entry] успешно обновлена.";fi
echo -e "${col_lgt}Обновление меню служб завершено.${col_r}";}
remove_existing_entry() {
if [ ! -f "$SERVICE_MENU_FILE" ]; then echo -e "${col_lrbg}${col_wt}Файл меню службы 'SendTo.desktop' не найден. Записи для удаления отсутствуют. \"$1\"${col_r}"
return;fi
entries=$(grep "\[Desktop Action sendtoremote_" "$SERVICE_MENU_FILE" | sed 's/\[Desktop Action sendtoremote_\(.*\)\]/\1/')
if [ -z "$entries" ]; then echo -e "${col_lrt}Записи для 'отправки на удаленный сервер' не найдены.${col_r}"
return;fi
echo -e "${col_ybg}${col_wt}»» Выберите запись для удаления:${col_r} (или нажмите ctrl+c для возврата в главное меню)"
trap "trap SIGINT;echo;return" SIGINT
select entry in $entries; do
if [ -n "$entry" ]; then echo -e "${col_lot}Вы выбрали для удаления: $entry ${col_r}"
sed -i "/\[Desktop Action sendtoremote_${entry}\]/,/\[Desktop Action/{\
	/\[Desktop Action sendtoremote_${entry}\]/d;\
	/\[Desktop Action/!d\
}" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/sendtoremote_${entry};//g" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/;sendtoremote_${entry}//g" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/sendtoremote_${entry}//g" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/;$//g" "$SERVICE_MENU_FILE"
echo -e "${col_lgt}Запись успешно удалена.${col_r}"
break
else echo -e "${col_lrt}Неверный выбор. Пожалуйста, попробуйте снова.${col_r}"
fi;done;trap SIGINT;}
echo
while true; do
echo -e "${col_dgbg}${col_wt}► Выберите опцию:${col_r}"
echo -e "1. ${col_lcy}Добавить новую запись 'отправить на удаленный сервер'${col_r}"
echo -e "2. ${col_lot}Удалить существующую запись 'отправить на удаленный сервер'${col_r}"
echo -e "3. ${col_lrt}Выйти${col_r}"
read -p "Введите ваш выбор (1-3): " choice
case $choice in
1) add_new_entry;;
2) remove_existing_entry;;
3) echo -e "${col_lm}Выход.${col_r}";echo
exit 0;;
*) echo -e "${col_lrt}Неверный выбор. Пожалуйста, введите 1, 2 или 3.${col_r}";;
esac
echo
done
