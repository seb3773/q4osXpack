#!/bin/bash
dn=$(dirname "$1")
if [ -x "$1" ]; then konsole --noclose --type su --workdir "$dn" -e "$1";else
tdesudo chmod +x "$1";konsole --noclose --type su --workdir "$dn" -e "$1";fi