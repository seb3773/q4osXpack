#!/bin/bash
bn=$(basename "$2");if [[ $2 == "system:/users/"* ]];then path="/home/${2#system:/users/}"
elif [[ $2 == "system:/documents/"* ]];then path="$(xdg-user-dir DOCUMENTS)/${2#system:/documents/}"
elif [[ $2 == "system:/media/"* ]];then input=$2;device=$(echo "$input" | awk -F 'system:/media/' '{print $2}' | awk -F '/' '{print $1}');dpath="$(lsblk -no MOUNTPOINT /dev/$device)";path="$dpath/$(echo "$input" | sed "s|system:/media/$device/||")"
else path="$2";fi
case "$1" in
"desk")
if test -f "$path";then \cp "$path" "$(xdg-user-dir DESKTOP)/$bn";fi;;
"docs")
if test -f "$path";then \cp "$path" "$(xdg-user-dir DOCUMENTS)/$bn";fi;;
"zip")
if test -e "$path";then cd "$(dirname "$path")";fbns=("$bn")
for arg in "${@:3}";do fbns+=("$(basename "$arg")");done
if test -f "$path";then aname="$(basename "$path" | sed 's/\.[^.]*$//').zip"
if [ "$aname" = "$(basename "$path")" ]; then kdialog --error "Kann kein Archiv aus einem komprimierten Verzeichnis erstellen."
else zip -jy "$aname" "${fbns[@]}";fi
elif test -d "$path";then zip -ry "$bn.zip" "${fbns[@]}";fi;fi;;
"usb")
devc=$(ls /media/$USER)
if [ -z "$devc" ];then	kdialog --error "Kein angeschlossenes USB-Speichergerät.";exit 1;fi
ndev=$(echo "$devc" | wc -w);if [ $ndev -eq 1 ];then sdevc=$devc;else lst=""
for dve in $devc;do lst="$lst '$dve' '$dve' off";done
seldev=$(kdialog --title "" --radiolist "Wählen Sie das USB-Speichergerät aus:" $lst --icon usb)
if [ $? -eq 1 ];then exit 1
else sdevc=$(echo $seldev | sed "s/'//g");fi;fi
\cp "$path" "/media/$USER/$sdevc/" > /dev/null 2>&1
if [ $? -eq 0 ];then kdialog --passivepopup "" 2 --title "Datei(en) wurde(n) nach $sdevc kopiert."
else kdialog --error "Fehler beim Kopieren nach $sdevc." --icon error
fi;;esac
