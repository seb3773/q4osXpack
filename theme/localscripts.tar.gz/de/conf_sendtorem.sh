#!/bin/bash
USER_HOME=$(eval echo ~${SUDO_USER})
SERVICE_MENU_FILE="$USER_HOME/.trinity/share/apps/konqueror/servicemenus/SendTo.desktop"
col_lrbg='\033[101m';col_wt='\033[97m';col_r='\033[0m';col_lrt='\033[91m';col_lgt='\033[92m'
col_lot='\033[38;5;214m';col_bt='\033[30m';col_ybg='\033[43m';col_dgbg='\033[100m';col_mag='\033[105m'
col_lcy='\033[96m';col_lm='\033[95m'
col_wt='\033[97m';col_lbbg='\033[104m';col_cy='\033[46m';echo -e -n "${col_r}"
add_new_entry() {
remotes=$(rclone listremotes)
if [ -z "$remotes" ]; then
echo -e "${col_lrt}Keine konfigurierten Remote-Verbindungen gefunden. Beende.${col_r}"
exit 1;fi
echo -e "${col_lbbg}${col_wt}»» Wählen Sie eine Remote-Verbindung aus: ${col_r} (oder ctrl+C, um zum Hauptmenü zurückzukehren)"
trap "trap SIGINT;echo;return" SIGINT
select remote in $remotes; do
if [ -n "$remote" ]; then remtype=$(rclone listremotes --long | grep "^${remote}" | awk '{print $2}')
echo -e "Sie haben ausgewählt: $remote  -- ${col_lgt}[ Remote-Typ: $remtype ]${col_r}"
break
else echo -e "${col_lrt}Ungültige Auswahl. Bitte versuchen Sie es erneut.${col_r}"
fi;done
echo -e "${col_mag}${col_bt}»» Geben Sie den Verzeichnispfad ein, um Dateien zu empfangen${col_r} (bestehend oder neu)"
echo -e -n "${col_wt}"
read dir_path
echo -e -n "${col_r}"
echo -e -n "Überprüfung..."
if rclone lsd "${remote}${dir_path}" &>/dev/null; then echo -e "${col_lgt}Ok, Verzeichnis existiert auf dem Remote.${col_r}"
else echo;echo "Verzeichnis existiert nicht auf dem Remote-System, versuche es zu erstellen..."
echo -e -n "${col_lot}"
if rclone mkdir "${remote}${dir_path}"; then echo -e -n "${col_r}"
echo -e "${col_lgt}Verzeichnis erfolgreich auf dem Remote-System erstellt.${col_r}"
else echo -e "${col_lrbg}${col_wt}Fehler: Verzeichnis konnte auf dem Remote-System ${remote} nicht erstellt werden${col_r}"
trap SIGINT;return
fi;fi
echo -e -n "Teste Schreibberechtigung..."
test_file="${remote}${dir_path}/write_test_$(date +%s)"
if ! echo "test" | rclone rcat "$test_file" 2>/dev/null; then
echo;echo -e "${col_lrbg}${col_wt}Fehler: Kann nicht in das angegebene Verzeichnis schreiben. Bitte überprüfen Sie Ihre Berechtigungen.${col_r}"
trap SIGINT;return
else echo -e "${col_lgt}Ok.${col_r}"
fi
rclone delete "$test_file" 2>/dev/null
while true; do
echo -e "${col_cy}${col_bt}»» Geben Sie einen benutzerdefinierten Namen für diesen Remote im Menü ein ${col_r} (oder drücken Sie die Eingabetaste, um \"${remote}\" zu verwenden):"
echo -e -n "${col_wt}"
read custom_name
echo -e -n "${col_r}"
if [ -z "$custom_name" ]; then custom_name="${remote%:}"
break
else
cleaned_name=$(echo "${custom_name}" | tr -cd '[:alnum:]_-')
if [ "$cleaned_name" = "$custom_name" ]; then break
else echo -e "${col_lrt}Ungültige Zeichen erkannt. Bitte verwenden Sie nur alphanumerische Zeichen, Unterstriche und Bindestriche.${col_r}"
echo "Möchten Sie stattdessen \"$cleaned_name\" verwenden? (j/n)"
read response
if [[ $response =~ ^[Jj]$ ]]; then custom_name=$cleaned_name
break
fi;fi;fi
done
trap SIGINT
echo -e "Verwenden von Name: ${col_lgt} ${custom_name} ${col_r}"
echo -e "${col_lgt}Remote und Verzeichniseinrichtung abgeschlossen.${col_r}";echo
if [ ! -f "$SERVICE_MENU_FILE" ]; then
echo "Service-Menüdatei nicht gefunden. Erstelle sie..."
mkdir -p "$(dirname "$SERVICE_MENU_FILE")"
touch "$SERVICE_MENU_FILE";fi
if ! echo "$remtype" | grep -E -q "combine|ftp|http|smb|sftp"; then remtype="${remtype// /_}"
oldremtype="$remtype";if [ "$remtype" = "box" ];then remtype="boxdotcom";fi
if [ ! -e "/usr/share/icons/hicolor/128x128/apps/${remtype}.png" ]; then echo "Versuche, ein Symbol für den Remote-Typ $oldremtype abzurufen"
if [ "$remtype" = "box" ];then remtype="boxdotcom";fi
wget -q "https://github.com/seb3773/icons_repo/blob/main/sendtoremote/${remtype}.png?raw=true" -O "/tmp/${remtype}.png"
if [ $? -eq 0 ]; then
if [ ! "$EUID" -eq 0 ];then echo "Wir benötigen Autorisierung, um das Symbol in den Ordner '/usr/share/icons/hicolor/' zu kopieren";fi
sudo cp -f "/tmp/${remtype}.png" "/usr/share/icons/hicolor/128x128/apps/${remtype}.png"
rem_icon="$remtype"
rm -f "/tmp/${remtype}.png"
else rem_icon="folder-remote";fi
else rem_icon="$remtype";fi
else rem_icon="folder-remote";fi
NEW_ENTRY="[Desktop Action sendtoremote_${custom_name}]
Name=${custom_name}
Icon=${rem_icon}
Exec=sendto.sh remote %U \"${remote}${dir_path}\"
"
if grep -q "sendtoremote_${custom_name}" "$SERVICE_MENU_FILE"; then echo -e "${col_lrt}Eintrag für ${custom_name} existiert bereits im Service-Menü.${col_r}"
else echo "Füge neuen Eintrag zum Service-Menü hinzu..."
echo "$NEW_ENTRY" >> "$SERVICE_MENU_FILE"
echo -e "${col_lgt}Eintrag erfolgreich hinzugefügt.${col_r}"
if grep -q "^\[Desktop Entry\]" "$SERVICE_MENU_FILE"; then if ! grep -q "^Actions=" "$SERVICE_MENU_FILE"; then
sed -i "/\[Desktop Entry\]/a Actions=sendtoremote_${custom_name}" "$SERVICE_MENU_FILE"
else sed -i "/^Actions=/ s/$/;sendtoremote_${custom_name}/" "$SERVICE_MENU_FILE"
fi
else DESKTOP_ENTRY="[Desktop Entry]
X-TDE-ServiceTypes=all/allfiles
X-TDE-Priority=TopLevel
X-TDE-Submenu=Send to
X-TDE-Submenu[fr]=Envoyer vers
X-TDE-Submenu[de]=Senden an
Actions=sendtoremote_${custom_name}"
sed -i "1i$DESKTOP_ENTRY" "$SERVICE_MENU_FILE";fi
echo "[Desktop Entry] Abschnitt erfolgreich aktualisiert.";fi
echo -e "${col_lgt}Aktualisierung des Service-Menüs abgeschlossen.${col_r}";}
remove_existing_entry() {
if [ ! -f "$SERVICE_MENU_FILE" ]; then echo -e "${col_lrbg}${col_wt}Service-Menüdatei 'SendTo.desktop' nicht gefunden. Es gibt keine Einträge zum Entfernen. \"$1\"${col_r}"
return;fi
entries=$(grep "\[Desktop Action sendtoremote_" "$SERVICE_MENU_FILE" | sed 's/\[Desktop Action sendtoremote_\(.*\)\]/\1/')
if [ -z "$entries" ]; then echo -e "${col_lrt}Keine 'send to remote'-Einträge gefunden.${col_r}"
return;fi
echo -e "${col_ybg}${col_wt}»» Wählen Sie einen Eintrag zum Entfernen aus:${col_r} (oder ctrl+C, um zum Hauptmenü zurückzukehren)"
trap "trap SIGINT;echo;return" SIGINT
select entry in $entries; do
if [ -n "$entry" ]; then echo -e "${col_lot}Sie haben ausgewählt, zu entfernen: $entry ${col_r}"
sed -i "/\[Desktop Action sendtoremote_${entry}\]/,/\[Desktop Action/{\
	/\[Desktop Action sendtoremote_${entry}\]/d;\
	/\[Desktop Action/!d\
}" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/sendtoremote_${entry};//g" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/;sendtoremote_${entry}//g" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/sendtoremote_${entry}//g" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/;$//g" "$SERVICE_MENU_FILE"
echo -e "${col_lgt}Eintrag erfolgreich entfernt.${col_r}"
break
else echo -e "${col_lrt}Ungültige Auswahl. Bitte versuchen Sie es erneut.${col_r}"
fi;done;trap SIGINT;}
echo
while true; do
echo -e "${col_dgbg}${col_wt}► Wählen Sie eine Option:${col_r}"
echo -e "1. ${col_lcy}Neuen 'Senden an Remote' Eintrag hinzufügen${col_r}"
echo -e "2. ${col_lot}Vorhandenen 'Senden an Remote' Eintrag entfernen${col_r}"
echo -e "3. ${col_lrt}Beenden${col_r}"
read -p "Geben Sie Ihre Auswahl ein (1-3): " choice
case $choice in
1) add_new_entry;;
2) remove_existing_entry;;
3) echo -e "${col_lm}Beendet.${col_r}";echo
exit 0;;
*) echo -e "${col_lrt}Ungültige Auswahl. Bitte geben Sie 1, 2 oder 3 ein.${col_r}";;
esac
echo
done
