#!/bin/bash
dn=$(dirname "$(readlink -f "$1")");if [ -x "$1" ];then konsole --noclose --workdir "$dn" -e "$1"
else tdesudo chmod +x "$1";konsole --noclose --workdir "$dn" -e "$1";fi