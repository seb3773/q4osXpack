#!/bin/bash
tp=$(kreadconfig --file "$1" --group "Desktop Entry" --key Type)
nm=$(kreadconfig --file "$1" --group "Desktop Entry" --key Name)
gnm=$(kreadconfig --file "$1" --group "Desktop Entry" --key GenericName)
ic=$(kreadconfig --file "$1" --group "Desktop Entry" --key Icon)
tr=$(kreadconfig --file "$1" --group "Desktop Entry" --key Terminal)
usrn=$(kreadconfig --file "$1" --group "Desktop Entry" --key X-TDE-Username)
subid=$(kreadconfig --file "$1" --group "Desktop Entry" --key X-TDE-SubstituteUID)
menufile="$TDEHOME/share/apps/kooldock/menu/xx_$(basename $1)"
kwriteconfig --file "$menufile" --group "Desktop Entry" --key Name "$nm"
kwriteconfig --file "$menufile" --group "Desktop Entry" --key GenericName "$gnm"
kwriteconfig --file "$menufile" --group "Desktop Entry" --key Icon "$ic"
kwriteconfig --file "$menufile" --group "Desktop Entry" --key Type "$tp"
kwriteconfig --file "$menufile" --group "Desktop Entry" --key Terminal "$tr"
if [ ! -z "$usrn" ];then kwriteconfig --file "$menufile" --group "Desktop Entry" --key X-TDE-Username "$usrn";fi
if [ ! -z "$subid" ];then kwriteconfig --file "$menufile" --group "Desktop Entry" --key X-TDE-SubstituteUID "$subid";fi
ex=$(grep "Exec=" "$1" | grep -v '^#')
if [ ! -z "$ex" ];then echo $ex >> "$menufile"
else ex=$(grep 'Exec\[$e\]=' "$1" | grep -v '^#');ex=${ex#Exec\[\$e\]=}
echo "Exec=$ex" >> "$menufile";fi
dcop kooldock MainApplication-Interface quit
kooldock &
