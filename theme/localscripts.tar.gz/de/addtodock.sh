#!/bin/bash
cp -f "$1" "$TDEHOME/share/apps/kooldock/menu/xx_$(basename $1)"
dcop kooldock MainApplication-Interface quit
kooldock &
