#!/bin/bash
prg=$(basename "$1");if [ "$prg" = "konsole.desktop" ];then konsole --type su;else
tdesudo -c ls /dev/null -d -i password --comment "Ausführen von $prg als Administrator"
oksu=$(sudo -n echo 1 2>&1 | grep 1);if [[ $oksu -eq 1 ]];then exe=$(grep -oP "(?<=^Exec=).*" "$1" | sed 's/%.//g');sudo $exe;fi;fi