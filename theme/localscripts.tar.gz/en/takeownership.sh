#!/bin/bash
bn=$(basename "$1")
if [[ $1 == "system:/users/"* ]];then path="/home/${1#system:/users/}";
elif [[ $1 == "system:/documents/"* ]];then path="$(xdg-user-dir DOCUMENTS)/${1#system:/documents/}";else path="$1";fi
tdesudo -c ls /dev/null -d -i password --comment "Take $bn ownership"
sudo chown -R $USER:$USER "$path"
