#!/bin/bash
USER_HOME=$(eval echo ~${SUDO_USER})
SERVICE_MENU_FILE="$USER_HOME/.trinity/share/apps/konqueror/servicemenus/SendTo.desktop"
col_lrbg='\033[101m';col_wt='\033[97m';col_r='\033[0m';col_lrt='\033[91m';col_lgt='\033[92m'
col_lot='\033[38;5;214m';col_bt='\033[30m';col_ybg='\033[43m';col_dgbg='\033[100m';col_mag='\033[105m'
col_lcy='\033[96m';col_lm='\033[95m'
col_wt='\033[97m';col_lbbg='\033[104m';col_cy='\033[46m';echo -e -n "${col_r}"
add_new_entry() {
remotes=$(rclone listremotes)
if [ -z "$remotes" ]; then
echo -e "${col_lrt}No configured remotes found. Exiting.${col_r}"
exit 1;fi
echo -e "${col_lbbg}${col_wt}»» Select a remote: ${col_r} (or ctrl+c to return to main menu)"
trap "trap SIGINT;echo;return" SIGINT
select remote in $remotes; do
if [ -n "$remote" ]; then remtype=$(rclone listremotes --long | grep "^${remote}" | awk '{print $2}')
echo -e "You selected: $remote  -- ${col_lgt}[ Remote type: $remtype ]${col_r}"
break
else echo -e "${col_lrt}Invalid selection. Please try again.${col_r}"
fi;done
echo -e "${col_mag}${col_bt}»» Enter the directory path to receive files${col_r} (existing or new)"
echo -e -n "${col_wt}"
read dir_path
echo -e -n "${col_r}"
echo -e -n "Checking..."
if rclone lsd "${remote}${dir_path}" &>/dev/null; then echo -e "${col_lgt}Ok, directory exists on the remote.${col_r}"
else echo;echo "Directory doesn't exists on the remote, trying to create it..."
echo -e -n "${col_lot}"
if rclone mkdir "${remote}${dir_path}"; then echo -e -n "${col_r}"
echo -e "${col_lgt}Directory created successfully on the remote.${col_r}"
else echo -e "${col_lrbg}${col_wt}Error: Failed to create directory on the remote ${remote} ${col_r}"
trap SIGINT;return
fi;fi
echo -e -n "Testing write permission..."
test_file="${remote}${dir_path}/write_test_$(date +%s)"
if ! echo "test" | rclone rcat "$test_file" 2>/dev/null; then
echo;echo -e "${col_lrbg}${col_wt}Error: Cannot write to the specified directory. Please check your permissions.${col_r}"
trap SIGINT;return
else echo -e "${col_lgt}Ok.${col_r}"
fi
rclone delete "$test_file" 2>/dev/null
while true; do
echo -e "${col_cy}${col_bt}»» Enter a custom name for this remote in the menu ${col_r} (or press Enter to use \"${remote}\"):"
echo -e -n "${col_wt}"
read custom_name
echo -e -n "${col_r}"
if [ -z "$custom_name" ]; then custom_name="${remote%:}"
break
else
cleaned_name=$(echo "${custom_name}" | tr -cd '[:alnum:]_-')
if [ "$cleaned_name" = "$custom_name" ]; then break
else echo -e "${col_lrt}Invalid characters detected. Please use only alphanumeric characters, underscores, and hyphens.${col_r}"
echo "Would you like to use \"$cleaned_name\" instead? (y/n)"
read response
if [[ $response =~ ^[Yy]$ ]]; then custom_name=$cleaned_name
break
fi;fi;fi
done
trap SIGINT
echo -e "Using name: ${col_lgt} ${custom_name} ${col_r}"
echo -e "${col_lgt}Remote and directory setup complete.${col_r}";echo
if [ ! -f "$SERVICE_MENU_FILE" ]; then
echo "Service menu file not found. Creating it..."
mkdir -p "$(dirname "$SERVICE_MENU_FILE")"
touch "$SERVICE_MENU_FILE";fi
if ! echo "$rem_type" | grep -E -q "combine|ftp|http|smb|sftp"; then remtype="${remtype// /_}"
if [ ! -e "/usr/share/icons/hicolor/128x128/apps/${remtype}.png" ]; then echo "Trying to retrieve icon for remote type ${remtype}"
if [ "$remtype" = "box" ];then remtype="boxdotcom";fi
wget -q "https://github.com/seb3773/icons_repo/blob/main/sendtoremote/${remtype}.png?raw=true" -O "/tmp/${remtype}.png"
if [ $? -eq 0 ]; then
if [ ! "$EUID" -eq 0 ];then echo "Now we need authorization to copy the icon in '/usr/share/icons/hicolor/' folder";fi
sudo cp -f "/tmp/${remtype}.png" "/usr/share/icons/hicolor/128x128/apps/${remtype}.png"
rem_icon="$remtype"
rm -f "/tmp/${remtype}.png"
else rem_icon="folder-remote";fi
else rem_icon="$remtype";fi
else rem_icon="folder-remote";fi
NEW_ENTRY="[Desktop Action sendtoremote_${custom_name}]
Name=${custom_name}
Icon=${rem_icon}
Exec=sendto.sh remote %U \"${remote}${dir_path}\"
"
if grep -q "sendtoremote_${custom_name}" "$SERVICE_MENU_FILE"; then echo -e "${col_lrt}Entry for ${custom_name} already exists in the service menu.${col_r}"
else echo "Adding new entry to service menu..."
echo "$NEW_ENTRY" >> "$SERVICE_MENU_FILE"
echo -e "${col_lgt}Entry added successfully.${col_r}"
if grep -q "^\[Desktop Entry\]" "$SERVICE_MENU_FILE"; then if ! grep -q "^Actions=" "$SERVICE_MENU_FILE"; then
sed -i "/\[Desktop Entry\]/a Actions=sendtoremote_${custom_name}" "$SERVICE_MENU_FILE"
else sed -i "/^Actions=/ s/$/;sendtoremote_${custom_name}/" "$SERVICE_MENU_FILE"
fi
else DESKTOP_ENTRY="[Desktop Entry]
X-TDE-ServiceTypes=all/allfiles
X-TDE-Priority=TopLevel
X-TDE-Submenu=Send to
X-TDE-Submenu[fr]=Envoyer vers
X-TDE-Submenu[de]=Senden an
Actions=sendtoremote_${custom_name}"
sed -i "1i$DESKTOP_ENTRY" "$SERVICE_MENU_FILE";fi
echo "[Desktop Entry] section updated successfully.";fi
echo -e "${col_lgt}Service menu update complete.${col_r}";}
remove_existing_entry() {
if [ ! -f "$SERVICE_MENU_FILE" ]; then echo -e "${col_lrbg}${col_wt}Service menu file 'SendTo.desktop' not found. No entries to remove. \"$1\"${col_r}"
return;fi
entries=$(grep "\[Desktop Action sendtoremote_" "$SERVICE_MENU_FILE" | sed 's/\[Desktop Action sendtoremote_\(.*\)\]/\1/')
if [ -z "$entries" ]; then echo -e "${col_lrt}No 'send to remote' entries found.${col_r}"
return;fi
echo -e "${col_ybg}${col_wt}»» Select an entry to remove:${col_r} (or ctrl+c to return to main menu)"
trap "trap SIGINT;echo;return" SIGINT
select entry in $entries; do
if [ -n "$entry" ]; then echo -e "${col_lot}You selected to remove: $entry ${col_r}"
sed -i "/\[Desktop Action sendtoremote_${entry}\]/,/\[Desktop Action/{\
	/\[Desktop Action sendtoremote_${entry}\]/d;\
	/\[Desktop Action/!d\
}" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/sendtoremote_${entry};//g" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/;sendtoremote_${entry}//g" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/sendtoremote_${entry}//g" "$SERVICE_MENU_FILE"
sed -i "/^Actions=/ s/;$//g" "$SERVICE_MENU_FILE"
echo -e "${col_lgt}Entry removed successfully.${col_r}"
break
else echo -e "${col_lrt}Invalid selection. Please try again.${col_r}"
fi;done;trap SIGINT;}
echo
while true; do
echo -e "${col_dgbg}${col_wt}► Select an option:${col_r}"
echo -e "1. ${col_lcy}Add new 'send to remote' entry${col_r}"
echo -e "2. ${col_lot}Remove existing 'send to remote' entry${col_r}"
echo -e "3. ${col_lrt}Quit${col_r}"
read -p "Enter your choice (1-3): " choice
case $choice in
1) add_new_entry;;
2) remove_existing_entry;;
3) echo -e "${col_lm}Exited.${col_r}";echo
exit 0;;
*) echo -e "${col_lrt}Invalid choice. Please enter 1, 2, or 3.${col_r}";;
esac
echo
done
