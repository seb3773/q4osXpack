#!/bin/bash
dn=$(dirname "$1")
if [ -x "$1" ]; then konsole --workdir "$dn" -e "$1";else
tdesudo chmod +x "$1";konsole --workdir "$dn" -e "$1";fi